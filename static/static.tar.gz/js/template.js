$(document).ready(function() {
    $(".item").height(Math.max($(window).height()-60,596));
});
$(window).resize(function() {
    $(".item").height(Math.max($(window).height()-60,596));
});
